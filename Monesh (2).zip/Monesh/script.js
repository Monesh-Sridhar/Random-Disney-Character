var spider = document.getElementById("spider");
var mickey = document.getElementById("mickey");
var captain = document.getElementById("captain");
var iron = document.getElementById("iron");

var spiderPic = document.getElementById("spider-image");
var mickeyPic = document.getElementById("mickey-image");

var random_character = "";

function random()
{
	var random = Math.floor(Math.random() * 4);

	if(random == 0)
	{
		spider.style.display = "block";
		mickey.style.display = "none";
		captain.style.display = "none";
		iron.style.display = "none";
		random_character = "Spider-Man";
	}

	if(random == 1)
	{
		spider.style.display = "none";
		mickey.style.display = "block";
		captain.style.display = "none";
		iron.style.display = "none";
		random_character = "Mickey Mouse";
	}

	if(random == 2)
	{
		spider.style.display = "none";
		mickey.style.display = "none";
		captain.style.display = "block";
		iron.style.display = "none";
		random_character = "Captain America";
	}

	if(random == 3)
	{
		spider.style.display = "none";
		mickey.style.display = "none";
		captain.style.display = "none";
		iron.style.display = "block";
		random_character = "Iron Man";
	}
}

function my_character()
{
	var my_character = document.getElementById("my_character").value;
	document.getElementById("my_select").innerHTML=my_character;
}

function slider()
{
	var slider = document.getElementById("slider").value;

	if(slider >= 0 && slider <= 3)
	{
		document.getElementById("rating").innerHTML="Hate it";
	}
	if(slider >= 4 && slider <= 7)
	{
		document.getElementById("rating").innerHTML="Like it";
	}
	if(slider >= 8 && slider <= 10)
	{
		document.getElementById("rating").innerHTML="Love it!";
	}
}

function compare()
{
	var my_character = document.getElementById("my_character").value;
	if(random_character == my_character)
	{
		alert('You Win!');
	}
	else
	{
		alert('You Lose!');
	}
}

function show_links()
{
	var link = document.getElementById("nav_links");
	link.style.display = "block";
}

function showSpider()
{
	mickeyPic.style.display = "none";
	spiderPic.style.display = "block";	
}

function showMickey()
{
	mickeyPic.style.display = "block";
	spiderPic.style.display = "none";	
}